const mongoose = require('mongoose');

// Connect to MongoDB database
mongoose
    .connect('mongodb://127.0.0.1:27017/authtest')
    .then(() => console.log("Connected to MongoDB"))
    .catch((err) => console.error("Error connecting to MongoDB:", err));

// Define authentication schema
const authSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    pass: {
        type: String,
        required: true
    }
});

// Create 'auth' model based on authSchema, with 'creds' collection name
const auth = mongoose.model('auth', authSchema, 'creds');

module.exports = auth;
