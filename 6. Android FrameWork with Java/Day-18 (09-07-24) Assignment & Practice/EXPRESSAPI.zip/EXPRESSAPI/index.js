const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const bodyParser = require('body-parser');
const db = require('./db/db'); // Assuming this handles database operations

// Middleware
app.use(bodyParser.json());

// Root route
app.get('/', (req, res) => res.send('Hello World!'));

// Login route
app.post("/login", async (req, res) => {
    const body = req.body;
    const email = body.email;
    const pass = body.pass;

    try {
        const result = await db.find({"email": email, "pass": pass});
        if(result.length === 1) {
            res.json({msg: "Login successful", status: 200});
        } else {
            res.json({msg: "Login failed", status: 400});
        }
    } catch (err) {
        console.error("Error during login:", err);
        res.status(500).json({msg: "Internal Server Error"});
    }
});

// Register route
app.post("/register", async (req, res) => {
    const body = req.body;

    try {
        const result = await db.create(body);
        res.status(201).json({msg: "User registered successfully"});
    }
    catch (err) {
        console.error("Error during registration:", err);
        res.status(500).json({msg: "Internal Server Error"});
    }
});

// Start the server
app.listen(port, () => console.log(`App listening on port ${port}!`));
