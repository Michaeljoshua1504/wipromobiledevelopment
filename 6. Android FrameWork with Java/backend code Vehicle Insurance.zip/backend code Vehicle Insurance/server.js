const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const User = require('./models/user');
const Vehicle = require('./models/vehicle');
const Claim = require('./models/claim');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// MongoDB connection setup
const mongo_uri = process.env.mongo_uri || 'mongodb+srv://Cluster46831:d3lbcltXfUF8@cluster46831.jf4jkge.mongodb.net/vehicle_insurance';
mongoose.connect(mongo_uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.error('Failed to connect to MongoDB', err);
});

// Signup endpoint
app.post('/signup', async (req, res) => {
  const { name, email, password, dob } = req.body;
  try {
    console.log('Received signup request:', req.body);
    const newUser = new User({ name, email, password, dob });
    await newUser.save();
    const userId = newUser._id;

    console.log('User created successfully:', newUser);
    res.status(201).json({ message: 'User created successfully', userId });
  } catch (error) {
    console.error('Error creating user:', error.message);
    res.status(500).json({ error: `Server error, failed to create user: ${error.message}` });
  }
});

// Login endpoint
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email, password });

    if (user) {
      const { _id: userId, name, email } = user;

      // Fetch vehicle details for the logged-in user
      const vehicle = await Vehicle.findOne({ userId });

      res.json({ 
        success: true, 
        message: 'Login successful', 
        userId, 
        name, 
        email,
        vehicle: {
          userId: vehicle.userId,
          vehicleType: vehicle.vehicleType,
          vehicleNumber: vehicle.vehicleNumber,
          vehicleOwnerName: vehicle.vehicleOwnerName,
          vehiclePolicy: vehicle.vehiclePolicy
        }
      });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ error: 'Server error, login failed' });
  }
});

// Save vehicle info endpoint
app.post('/vehicle-info', async (req, res) => {
  const { userId, vehicleType, vehicleNumber, vehicleOwnerName, vehiclePolicy } = req.body;
  try {
    const newVehicle = new Vehicle({ userId, vehicleType, vehicleNumber, vehicleOwnerName, vehiclePolicy });
    await newVehicle.save();
    res.status(201).json({
      message: 'Vehicle information saved successfully',
      vehicle: {
        userId: newVehicle.userId,
        vehicleType: newVehicle.vehicleType,
        vehicleNumber: newVehicle.vehicleNumber,
        vehicleOwnerName: newVehicle.vehicleOwnerName,
        vehiclePolicy: newVehicle.vehiclePolicy
      }
    });
  } catch (error) {
    console.error('Error saving vehicle information:', error);
    res.status(500).json({ error: 'Server error, failed to save vehicle information' });
  }
});

// File claim endpoint using multer for file upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  }
});
const upload = multer({ storage: storage });

app.post('/file-claim', upload.array('photos', 5), async (req, res) => {
  const { userId, description } = req.body;
  const photos = req.files.map(file => file.path);

  console.log('Request body:', req.body);
  console.log('Uploaded photos:', req.files);

  try {
    const newClaim = new Claim({ userId, description, photos });
    await newClaim.save();
    res.status(201).json({ message: 'Claim filed successfully' });
  } catch (error) {
    console.error('Error filing claim:', error);
    res.status(500).json({ error: 'Server error, failed to file claim' });
  }
});

// Endpoint to get vehicle details by userId
app.get('/vehicles/:userId', async (req, res) => {
  const userId = req.params.userId;
  try {
    const vehicle = await Vehicle.findOne({ userId });
    if (!vehicle) {
      return res.status(404).json({ error: 'Vehicle details not found' });
    }
    res.json(vehicle);
  } catch (error) {
    console.error('Error fetching vehicle details:', error);
    res.status(500).json({ error: 'Server error, failed to fetch vehicle details' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
